<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Contact Us</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>

    <!-- HEADER -->
        <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 
	

	<div class="section-about margin-top-100">
		<div class="container">
            <center>
				<h1 class="black-heading1 text-center" style="padding-bottom: 10px; border-bottom-width: 2px; border-bottom-style: solid; width: fit-content;">Get In Touch</h1>
            </center>
		</div>
	</div>
    
    
    
    
    
    <div class="contact-block1 base5">
        <div class="container">
        
        <div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                  <!--      <div class="icon-contact"><img src="images/contact-us/usa.png"/></div>-->
                        <div class="contact-info">
                            <h3 class="white-heading3">INDIA</h3>
                            <p><strong class="yellow-color">India Headoffice:</strong><br>
                             898 Udyog Vihar, Phase 1,<br>
                               Gurgaon, Haryana<br>
                             P: +124-421- 7800<br> E: india@eastboundgroup.com </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">UAE</h3>
                            <p>
                             Suite 106, Churchill Executive<br>
                             Tower, Business Bay,<br>
                              P.O. Box 114551, Dubai, UAE<br>
                              P: +971-43- 608-928 <br> E: asit@eastboundgroup.com </p>
                           
                        </div>
                    </div>
                </div>
              <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                          <h3 class="white-heading3">SRI LANKA</h3>
                            <p>Eastbound Sri Lanka<br>
                              20 Center Road 
Jayanthipura <br>
Battaramulla <br>
Sri Lanka<br>
P :+94 71 04 22 534<br>
<br>E: wyomi@eastboundgroup.com </p>
                      </div>
                    </div>
                </div>
                
                <div class="clearfix"></div>
               
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">BHUTAN</h3>
                            <p>
                             P/O Box 848, Kewang Building,<br>
                             Norzin Lam Thimpu,<br>
                              Bhutan<br>
                              P: +124-421- 7800<br> E: deepsika@eastboundgroup.com </p>
                           
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">NEPAL</h3>
                            <p>
                             525, Ranibari, Samakhushi,<br>
                             Kathmandu-3, Nepal<br>
                              P: +977 1 4350108<br> E: nepalbijay@eastboundgroup.com </p>
                           
                        </div>
                    </div>
                </div>
				
              
               
            </div>
        
        <div class="clearfix"></div>
        
 </p>
                        </div>
                    </div>
                </div>
                

            </div>
        </div>
    </div>
    
    
     
   
   
     <div id="contact-us"></div>
     <div class="main-container" style=" background-color: #f7eedc; margin-top:120px;">
    <div class="container" style="width: 100% !important;">
            <div class="row">
            <div class="col-sm-5">
                  <div class="container">
                  <h2 class="black-heading">Contact Us</h2>
                    <div class="contact-form style-2">
                        <div id="message-box-conact"></div>
                        <form method="post" action="thank-you.php">
                        <div class="form-group">
                            <input id="name" type="text" value="" placeholder="Name" name="name">
                        </div>
                         <div class="form-group">
                            <input id="email" type="text" value="" placeholder="Email"  name="email">
                        </div>
                         <div class="form-group">
                            <input id="subject" type="text" value="" placeholder="Phone" name="phone">
                        </div>
                         <div class="form-group">
                            <textarea id="content" rows="7" placeholder="Message" name="message"></textarea>
                        </div>
                        <div class="text-right">
                           <input type="submit" id="btn-send-contact" value="SEND">
                        </div>`
                        </form>
                    </div>
                </div>
                </div>
            
            
            
                <div class="col-sm-7 map-margin">
                    <div class="google-map">
        <div id="canvas-for-google-map" style="height:100%; width:100%;max-width:100%;"><iframe height="650"  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3505.7515181115236!2d77.08008131507994!3d28.517122782463577!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d195fa01750a1%3A0xb3db08767a08ca23!2sEastbound+Group!5e0!3m2!1sen!2sin!4v1481372565331" width="600"  frameborder="0" style="border:9px solid #d3ba39;" allowfullscreen></iframe></div>
    </div>
    <p class="text-center padding-top10"><strong>India Headoffice:</strong> 898 Udyog Vihar, Phase 1, Gurgaon, Haryana</p>
                </div>
            </div>
    </div>
    </div>
    
    		<div class="margin-top-90">
        <div class="section-title2 text-center">
            <h2 class="black-heading1">Eastbound Group</h2>
        </div>
        <div class="block-instagram owl-carousel" align="center" data-nav="false" data-dots="false" data-responsive='{"0":{"items":1},"600":{"items":4},"1000":{"items":10}}'>
            <a href="https://2hub.travel/"><img src="http://eastboundgroup.com/images/our_group/2hub.jpg" alt=""></a>
            <a href="http://www.chime.travel/"><img src="http://eastboundgroup.com/images/our_group/chimelogo.png" alt=""></a>
            <a href="http://eastboundgroup.com/"><img src="http://eastboundgroup.com/images/our_group/byond.jpg" alt=""></a>
            <a href="http://eastbounddiscoveries.com/"><img src="http://eastboundgroup.com/images/our_group/ebd.jpg" alt=""></a>
			 <a href="http://btsindia.com/"><img src="http://eastboundgroup.com/images/our_group/bts.png" alt=""></a>
			 
			 
        </div>
    </div>
	
    
    <div class="margin-top-90">
        <div class="section-title2 text-center">
            <h2 class="black-heading1">Eastbound Group Affiliations</h2>
          
        </div>
        <div class="block-instagram owl-carousel" data-nav="false" data-dots="false" data-responsive='{"0":{"items":1},"600":{"items":4},"1000":{"items":10}}'>
            <a href=""><img src="images/contact-us/1.png" alt=""></a>
             <a href=""><img src="images/contact-us/2.png" alt=""></a>
             <a href=""><img src="images/contact-us/3.png" alt=""></a>
             <a href=""><img src="images/contact-us/4.png" alt=""></a>
             <a href=""><img src="images/contact-us/5.png" alt=""></a>
             <a href=""><img src="images/contact-us/6.png" alt=""></a>
              <a href=""><img src="images/contact-us/7.png" alt=""></a>
              <a href=""><img src="images/contact-us/8.png" alt=""></a>
              <a href=""><img src="images/contact-us/9.png" alt=""></a>
			 <a href=""><img src="images/contact-us/10.png" alt=""></a>
        </div>
    </div>
   
    
    
    
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>