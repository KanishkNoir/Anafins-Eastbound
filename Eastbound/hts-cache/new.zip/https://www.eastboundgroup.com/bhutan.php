<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Bhutan</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
    <script type="text/javascript" src="js/popup1.js"></script>
    <script type="text/javascript" src="js/popup2.js"></script>

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>

<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
         <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="section-about margin-top-100">
		<div class="container">
			<div class="about-text text-center">
			
				<h1 class=" black-heading1">Journey Through Bhutan</h1>
               
				
				<p>The country that measures its growth with happiness – in Bhutan there are equally blissful mountains, food and people! Stunning vistas, fresh air and apple-cheeked children will greet you wherever you go – Bhutan is an experience in the sub-continent that should not be missed by the intrepid traveller.
 </p>
			</div>
			
		</div>
	</div>
    
    
    
  
        <div class="container">
            <!-- Blog maroonry -->
            <div id="blog-masonry" class="blog-masonry" data-cols="3">
                <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/1.jpg"></figure>
                                   </div>
                  <h4 class="blog-title"><a href="#">Gross National Happiness</a></h4>
                    <div class="content-post">
                        <p>The phrase ‘Gross National Happiness’ was coined in 1972 by Bhutan’s fourth Dragon King, Juigme Singye Wangchuck. And this is how the ‘ economic health’ of the nation is judged; by building an economy that would serve Bhutan’s culture based on Buddhist spiritual values instead of the material development in other parts of the world that is measured by gross domestic product (GDP). What a ‘happy’ theory indeed – and it has now defined the way Bhutanese live – happily ever after…
 </p>
                    </div>

                     <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a>
                </article>
                
                <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/2.jpg"></figure>
                                       </div>
                  <h4 class="blog-title"><a href="#">Culture</a></h4>
                    
                    <div class="content-post">
                        <p class="text-justify">Protected by the Himalayas, Bhutan’s geographic isolation has protected itself from cultural influences from the rest of the world – and it has been only recently that foreign tourists are being allowed into the country in limited numbers. Bhutanese language, script and its culture is closely related to what is seen in Tibet; and there are religious and physical similarities as well between the two as well.</p>
                    </div>

                    <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a><br><br>
                </article>
                
                <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/3.jpg"></figure>
                                      </div>
                  <h4 class="blog-title"><a href="#">Monasteries</a></h4>
                    
                    <div class="content-post">
                        <p>Silent, rugged and exuding an air of rare spiritual authority, Buddhist monks and their monasteries are also a scattered along Bhutan’s landscape. Revered and looked up to as healers and leaders of each Bhutanese community, these monasteries are as much a part of Bhutan’s landscape as its mountains.</p>
                    </div>
                     <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a><br><br><br><br><br>
                </article>
                
                
              <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/4.jpg"></figure>
                                          </div>
                <h4 class="blog-title"><a href="#">Festivals</a></h4>
                    
                    <div class="content-post">
                        <p>The best time to visit Bhutan is during its festivals. As the population was largely illiterate earlier, Bhutan’s masked dances and music was the best way for the kings and the religious heads to communicate to the masses.  </p>
                    </div>
                    <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a><br><br>
                </article>
                
                
               <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/5.jpg"></figure>
                                   </div>
                 <h4 class="blog-title"><a href="#">Walking Trail & Private Camping</a></h4>
                    
                    <div class="content-post">
                        <p>Bhutan’s terrain is largely forests and most trek paths will take you through forests, mountains covered with green foliage and flowers, birds chirping – it doesn’t more idyllic than this. Most treks use outdoor camps and the best season to trek in the area is from March to September/October.</p>
                    </div>
                     <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a>
                </article>
                
                
                
            <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/6.jpg"></figure>
                                   </div>
              <h4 class="blog-title"><a href="#">Nature Flora Fauna</a></h4>
                    
                    <div class="content-post">
                        <p>Despite its small landmass Bhutan has a remarkable abundance of flora and fauna and is one of the most biologically diverse regions of the world. Snow covered mountains and glaciers, all types of forests and vegetation make ideal grounds for a diverse range of flora, fauna, wildlife and birds to thrive.</p>
                    </div>
                     <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a>
                </article>
                
                
                
                <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/7.jpg"></figure>
                                        </div>
                  <h4 class="blog-title"><a href="#">Bhutanese Cusine</a></h4>
                  
                    
                    <div class="content-post">
                        <p>If you have to try one Bhutanese dish it has to be its National dish Imma Datchi – a concoction made of chillies, cheese and onions – its delicious with just plain rice. Rice features predominantly in all Bhutanese meals as does chicken, yak meat, dried beef, pork and lamb.</p>
                    </div>

                     <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a><br><br>
                </article>
                
                
                
                <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/bhutan/8.jpg"></figure>
                                         </div>
                  <h4 class="blog-title"><a href="#">Religion</a></h4>
                   
                    
                    <div class="content-post">
                        <p>Most Bhutanese practice Buddhism and this is evident all over the countryside with beautiful prayer flags, austere and calm monasteries and an air of calm spirituality</p>
                    </div>

                     <a class="button readmore-button" href="contact-us.php#contact-us">KNOW MORE</a>
                </article>
               
              
                
                
             
            </div>
            <!-- ./Blog maroonry -->
           
           
        </div>
    
   
   
	
    
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                       <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>