﻿<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="The promise of incomparable luxury travel experiences from Eastbound in India, Bhutan, UAE, Nepal, Sri Lanka. Our vision and service standards go beyond all expectations, and comparable to the very best in the world.."/>
    <title>Eastbound - Incomparable Luxury Travel Experiences</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css"/>
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css"/>
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css"/>
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css"/>
    <link rel="stylesheet" href="css/stylesheet.css" />
    <link rel="stylesheet" href="nexa-font/font.css" />
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/popup1.js"></script>
    <script type="text/javascript" src="js/popup2.js"></script>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<style>
    @media only screen and (max-width:700px){.new-slider{display:none;}}
    @media only screen and (min-width:701px){.old-slider{display:none;}}
</style>    
<body>

<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>


    <!-- HEADER -->
    <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    <div class="home-slide4 owl-carousel dot-styl2 nav-style2" data-items="1" data-nav="true" data-loop="true" data-autoplay="true">
     <a href="destinations.php"><img src="images/Slide1.png" alt=""></a>
      <a href="destinations.php"><img src="images/Slide2.png" alt=""></a>
        <a href="destinations.php"><img src="images/Slide3.png" alt=""></a>
       <a href="destinations.php"><img src="images/Slide4.png" alt=""></a>
       <a href="destinations.php"><img src="images/Slide5.png" alt=""></a>
    </div>
   
    <!-- /SLIDE -->

	<div class="section-about base1" style="width:100%;">
		<div class="container">
			<div class="about-text text-center" style="padding-top:0px;">
			
<h1 class="black-heading1">Welcome to Eastbound</h1>
                <h4 class="blue-heading">The promise of incomparable luxury travel experiences! </h4>
				<!--<div class="divider">
					<div class="divider-content">
						<span></span>
					</div>
				</div>-->
				<p>Founded in 2006, the company has grown to become the leading destination management company in Asia with <br>
full service operations in India, UAE, Sri Lanka, Nepal, Vietnam, Japan and Bhutan.
 </p>
			</div>
			
		</div>
	</div>
	
    
    <div class="section-ourblog1 base2" style="width:100%;">
        <div class="container">
           
            <div class="row">
                <div class="col-sm-5">
                 <h3 class="horizontal-line black-heading"><a href="services.php">Services</a></h3>
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/hs.png"></figure>
                        <a href="services.php" class="hover-format">
                            <span><i class="fa fa-link"></i></span>                        </a>                    </div>
                 
                    
<div class="content-post padding-top20">
                            <p>Bringing clients and destinations together distinctively and creatively - with a range of services that go far beyond, 
EB organises an eclectic range of experiences from Cultural to Wildlife, Ayurveda, Photography to Fishing, Art & Architecture to Culinary excellence.  All this at superlative service standards blended with luxury, quiet efficiency and
best possible costs.

</p>
                        </div>

                   
                </article>
                </div>
                
                <div class="col-sm-2">
                   <div class="line"></div>
                </div>
                
                
                <div class="col-sm-5">
                 <h3 class="black-heading horizontal-line"><a target="_blank" data-toggle="modal" data-target="#myModal" href="">Corporate Profile</a></h3>
                    <article class="blog-item style5 blog-item-masonry">
                        <div class="post-format">
                            <figure><img src="images/ep.png" alt=""></figure>
                            <a target="_blank" data-toggle="modal" data-target="#myModal" href="" class="hover-format">
                            <span><i class="fa fa-file-pdf-o"></i></span>                        </a>                        </div>
                        
                       
<div class="content-post padding-top20">
                            <p>Get inspired by the world of Eastbound, incomparable luxury travel experiences. Customized for private journeys, we deliver service standards that go beyond all expectations and comparable to the very best in the world </p>
                        </div>

                       
                    </article>
                    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content my-model">
        <div class="modal-header my-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title text-center">Eastbound Profile</h3>
        </div>
        <div class="modal-body">
           <p class="text-center">
               <a class="button primary round-icon" target="_blank" href="http://eastboundgroup.com/Eastbound%20-%20Profile%20HQ.pdf"><i class="icon fa fa fa-file-pdf-o"></i>High Resolution</a>
                <a class="button primary round-icon margin-top-30" target="_blank" href="http://eastboundgroup.com/Eastbound%20-%20Profile%20LQ.pdf"><i class="icon fa fa-file-pdf-o"></i>Low Resolution</a>
            </p>
        </div>
	
 </div>
    </div>
  </div>
                    
                </div>
            </div>
        </div>
    </div>
    
    
 
    <div class="section-about base9" style="background-color:#f7eedc;">
		<div class="container">
			<div class="about-text text-center margin-top-50">
			
				<h1 class="black-heading1">EB Experiential Travel</h1>
               
				
				<p style="max-width:930px; margin:auto;">Established by a group of highly respected travel professionals, EB is defined by its passion and commitment to create unparalleled journeys of discovery…of people, cultures, history, food, wellness and the spiritual, that translate into timeless stories.<br>
Eastbound lives through its deep-rooted network with ‘local owners of the heritage’ to deliver on this promise.
 </p>
			</div>
		</div>
	</div>
    
    
    
    <div class="section-portfolio2">
        <div class="bz-portfolio">
            <div class="bz-popup-gallery portfolio-grid portfolio-style2 pf-hover1" data-cols="5" data-layoutMode="fitRows">
                <div class="item-portfolio">
                  <a href="discovery-trips.php">  <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/dt.png" style="width:100%;" alt="">
                        </div>
                      <div class="pf-info text-center">
                            <div class="pf-content-info">    
                                <h3 class="white-heading1"><font size="4">Discovery Trips</font></h3>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>

                <div class="item-portfolio">
               <a href="adventure.php">  
                  <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/oe.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1"><font size="4">Outdoor Experience</font></h3>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>

                <div class="item-portfolio">
                 <a href="luxury-cruises.php"> 
                   <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/ls.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1"><font size="4">Luxury Cruises</font></h3>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>

                <div class="item-portfolio">
                 <a href="photography-tours.php"> 
                   <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/pt.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1"><font size="4">Photography Tours</font></h3>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
                
                <div class="item-portfolio">
                <a href="educational-tours.php">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/et.png" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1"><font size="4">Educational Travel</font></h3>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
				
				                <!--<div class="item-portfolio">
                 <a href="services.php"> 
                   <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/services/7.jpg" style="width:100%;" alt="">
                        </div>
                        <div class="pf-info text-center">
                            <div class="pf-content-info">    
                            <h3 class="white-heading1"><font size="4">MICE & Events</font></h3>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>-->
                
            </div>
        </div>
    </div>
    
    
    
    
    <div style="width:100%;">
    <center>   <a data-border_width="0" data-boder_color="#303030" data-border_hover_color="#e1571a" data-bg="#fff" data-bghover="#e1571a" data-text_color="#303030" data-text_color_hover="#fff" href="services.php" class="button-pt button" >EXPLORE MORE</a></center>
        <div class="container">
            <div class="row padding-top50 margin-bootom-30">
                <div class="col-sm-4 center-block">
                <h1 class="text-center pt-heading1">Culture & <br><span> Connecting People</span></h1>
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/Culture.png"/></figure>
                        <a href="discovery-trips.php" class="hover-format">
                            <span><i class="fa fa-link"></i></span></a>                                               </div>
                 
                    
                  <div class="content-post padding-top20">
                            <p class="pt-culture">Experience an incomparable journey which gives a whole new meaning connecting you with the destination through its people, culture and history. Meet people who matter, from various walks of life  will impact you, engage you and remain your friends for a long time to come.
                              </p>
                        </div>
                </article>
                </div>
                
                <div class="col-sm-4 center-block">
                <h1 class="text-center pt-heading1"> Wildlife  <br><span> Habitat</span></h1>
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/Wildlife.png"/></figure>
                        <a href="photography-tours.php" class="hover-format">
                            <span><i class="fa fa-link"></i></span></a>                                             </div>
                    
                  <div class="content-post padding-top20">
                            <p class="pt-culture">We create photography journeys that are simply incomparable. Led by our extremely well known and illustrious photographers, and accompanied by our highly accomplished talent pool of escorts, naturalists and field guides who are experts on India and the sub-continent, we bring an unparalleled Vision, Experience, Intensity and Art to the experience.
                                        </p>
                                       </div>
                </article>
                </div>
                
                <div class="col-sm-4 center-block">
               <h1 class="text-center pt-heading1">Unwind  <br> <span>in Style</span></h1>
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <figure><img alt="" src="images/Style.png"></figure>
                        <a href="luxury-cruises.php" class="hover-format">
                            <span><i class="fa fa-link"></i></span> </a>                                              </div>
                 
                    
                  <div class="content-post padding-top20">
                            <p class="pt-culture">Our signature touch extends seamlessly to luxury cruises around the Indian sub-continent, UAE, Maldives and Seychelles. We create incomparable experiences, aligning overland tours, and facilitating so completely… that we fulfill any cruise members dream!
                                     </p>
                        </div>
                </article>
                </div>
            </div>
        </div>
    </div>
    
    
    
    
    
	
	<div class="section-paralax-2  bg-parallax">
		<div class="overlay"></div>
		<div class="container">
			<div class="section-content text-center">
				<h1 class="white-heading">Corporate Social <font class="yellow-color">Responsibility</font></h1>
                <figure><img src="images/hsbn.png" style="border:2px solid #fff;" alt=""></figure>
				<p class="padding-top20">At Eastbound, we contribute to various schools, NGOs and organizations. Not only do we see it as just a part of our Corporate Social Responsibility, but it is our absolute commitment to fund and work aggressively on several projects in the areas of education, wildlife conservation and social growth. Across the board, we have a proactive environmental policy, train our teams in ‘green’ thinking and to be as ‘green’ as possible. We make regular donations to the Faith Foundation, an NGO devoted to providing financial independence to destitute and widowed women and schooling to children living in the various slums of Delhi and the NCR region. The NGO that was established in September, 2003, strives towards providing the financially weak with the means to make a better livelihood. 
</p>

			</div>
		</div>
	</div>
    
    <div class="base1"  style="height:300px;"></div>
    <div class="section-testimonial" style=" margin-top:-300px;">
        <div class="title-page-section">
        </div>
        <div class="container padding-top50">
        <h1 class="text-center black-heading1">Testimonials</h1>
        <h5 class="red-heading text-center">What our clients are saying about us</h5>
            <div class="">
                <div class="testimonials testimonials-style3 owl-carousel navigation-center-center" data-nav="true" data-dots="false" data-items="1" data-autoplay="true" data-loop="true">
                    <div class="testimonial">
                        <div class="avatar">
                            <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“Allow me to add my gratitude and my enthusiastic endorsement of Rohit’s extraordinary effort and professionalism. His execution of every logistical detail was flawless, but more importantly, his ability to operate with incomplete or ambiguous information, to respond to exigencies or unexpected contingencies, and to think ahead and avert problems is what makes Rohit the best travel coordinator I have seen. What makes him really special is the genuine interest he takes in us as people and in our educational enterprise. He is unflappable under pressure, warm and caring in all his interactions, and has a natural charisma that engenders trust and confidence. “</p>
                            <hr />
                            <h6>Anjani </h6>
                            <span>USA</span>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="avatar">
                          <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“I am writing to thank you and Ravi for helping to ensure that we had such a wonderful and memorable trip. You couldn’t have looked after us better and I congratulate you on having such an efficient team. We were particularly grateful for all the effort that Ravi must have put into getting us upgraded at the Umaid Bhawan and Lake Palace - please extend our special thanks to him! We are extremely happy and satisfied clients and we wish you well for the future”.</p>
                            <hr />
                            <h6>Morton Lim </h6>
                            <span>USA</span>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="avatar">
                           <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“We had an amazing time - you did a fantastic job of hitting the highlights for us and the places we stayed were just brilliant! Everything went smoothly with representatives meeting us; the guides - I just can’t thank you enough! The children enjoyed - not as much as me! It will be interesting to see what stories are told now we’re back - I know Elephantastic was a particular favourite as was Goa for them - I have a much longer list and the memories will be with us forever!”</p>
                            <hr />
                            <h6>Amanda </h6>
                            <span>UK</span>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="avatar">
                         <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“We have now returned from our travels in India and the UAE. We had a wonderful time. We are especially grateful to Salim at Eastbound Travel in Delhi, who did a very good job rearranging our travels in view of the general strike in Kerala on 26 January. Other than this disruption we had a great time. The accommodation was superb. The meals at the Malabar Residency in Cochin were very good indeed. From Calicut onwards we had a superb driver, Ramesh, who could not have been more positive and helpful. He was happy to add things to our agenda, and make suggestions where appropriate. He became quite a friend whilst he was with us. Thank you for arranging a superb trip.”</p>
                            <hr />
                            <h6>Andrew & Cath Beech </h6>
                            <span>UK</span>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="avatar">
                         <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“Very Well-done, we achieved a lot and felt safe. The guides were of a high calibre and were very knowledgeable and passionate. Our Driver was professional, courteous and kept us safe. Johnnie in Agra kept us entertained with his terrific sense of humour and storytelling. Overall, we found Eastbound to be incredibly professional.”</p>
                            <hr />
                            <h6>Cant</h6>
                            <span>Australia</span>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="avatar">
                         <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“The Tour has been excellent. All major attractions were covered and all guides were extremely knowledgeable and informative. Thank you to our tour team. Our tour was amazing. I would defiantly tour you guys again and highly recommend you to other Australian.”</p>
                            <hr />
                            <h6>Campbell</h6>
                            <span>Australia</span>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="avatar">
                       <img src="images/home-testi.jpg" alt="" />
                        </div>
                        <div class="inner">
                            <p>“Excellent services, great guides, the driver was particularly good. </p>
                            <hr />
                            <h6>Barbara</h6>
                            <span>Australia</span>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    
	

    <!-- Section tearm-->
      <div class="clearfix"></div>
    <!-- /SLIDE --> 
	<div class="section-about margin-top-30">
		<div class="container">
				<h1 class="black-heading1 text-center"><a href="http://eastboundgroup.com/Payment%20Policy/Privacy%20Policy_EB%20Tours.pdf" target="_blank">Privacy Policy</a> <br></br><a href="http://eastboundgroup.com/Payment%20Policy/Terms%20of%20Use_Eastbound%20Tours.pdf" target="_blank">Terms and Conditions</a><br></br><a href="http://eastboundgroup.com/corona.php" target="_blank" class="bz-main-mennu"><!--<img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />-->COVID-19 Updates</a></h1>
		</div>
	</div>
    

	<!--<div class="section-about margin-top-30">
		<div class="container">
				<h1 class="black-heading1 text-center">Get In Touch</h1>
		</div>
	</div>-->
    
    <div class="contact-block1 base5">
        <div class="container">
        
        <div class="row">
            <div class="section-about margin-top-30">
		        <div class="container">
                    <center>
				        <h1 class="black-heading1 text-center" style="padding-bottom: 10px; border-bottom-width: 2px; border-bottom-style: solid; width: fit-content;">Get In Touch</h1>
                    </center>
		        </div>
	        </div>
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                  <!--<div class="icon-contact"><img src="images/contact-us/usa.png"/></div>-->
                        <div class="contact-info">
                            <h3 class="white-heading3">INDIA</h3>
                            <p><strong class="yellow-color">India Headoffice:</strong><br>
                             898 Udyog Vihar, Phase 1,<br>
                               Gurgaon, Haryana<br>
                             P: +124-421- 7800<br> E: india@eastboundgroup.com </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">UAE</h3>
                            <p>
                             Suite 106, Churchill Executive<br>
                             Tower, Business Bay,<br>
                              P.O. Box 114551, Dubai, UAE<br>
                              P: +971-43- 608-928 <br> E: uae@eastboundgroup.com </p>
                           
                        </div>
                    </div>
                </div>
              <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">SRI LANKA</h3>
                            <p>Eastbound Sri Lanka<br>
20 Center Road <br>
Jayanthipura <br>
Battaramulla <br>
Sri Lanka<br>
P :+94 71 04 22 534<br> E: wyomi@eastboundgroup.com
</p>
                           
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
               
                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">BHUTAN</h3>
                            <p>
                             P/O Box 848, Kewang Building,<br>
                             Norzin Lam Thimpu,<br>
                              Bhutan<br>
                              P: +124-421- 7800<br> E: bhutan@eastboundgroup.com </p>
                           
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="bz-contact-info">
                       <!-- <div class="icon-contact"><img src="images/contact-us/uk.png"/></div>-->
                        <div class="contact-info">
                           <h3 class="white-heading3">NEPAL</h3>
                            <p>
                             525, Ranibari, Samakhushi,<br>
                             Kathmandu-3, Nepal<br>
                              P: +977 1 4350108<br> E: nepal@eastboundgroup.com </p>
                           
                        </div>
                    </div>
                </div>
              
                
            </div>
        
        <div class="clearfix"></div>
        
        
        
    
      
      <div class="main-container" style=" background-color: #f7eedc; margin-top:120px;">
    <div class="container">
            <div class="row">
            <div class="col-sm-5">
                  <div class="container">
                  <h2 class="black-heading">Contact Us</h2>
                    <div class="contact-form style-2">
                        <div id="message-box-conact"></div>
                        <form method="post" action="thank-you.php">
                        <div class="form-group">
                            <input id="name" type="text" value="" placeholder="Name" name="name">
                        </div>
                         <div class="form-group">
                            <input id="email" type="text" value="" placeholder="Email"  name="email">
                        </div>
                         <div class="form-group">
                            <input id="subject" type="text" value="" placeholder="Phone" name="phone">
                        </div>
                         <div class="form-group">
                            <textarea id="content" rows="7" placeholder="Message" name="message"></textarea>
                        </div>
                        <div class="text-right">
                           <input type="submit" id="btn-send-contact" value="SEND">
                        </div>
                        </form>
                    </div>
                </div>
                </div>
            
            
            
                <div class="col-sm-7 map-margin">
                    <div class="google-map">
        <div id="canvas-for-google-map" style="height:100%; width:100%;max-width:100%;"><iframe height="650"  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3505.7515181115236!2d77.08008131507994!3d28.517122782463577!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d195fa01750a1%3A0xb3db08767a08ca23!2sEastbound+Group!5e0!3m2!1sen!2sin!4v1481372565331" width="600"  frameborder="0" style="border:9px solid #d3ba39;" allowfullscreen></iframe></div>
    </div>
    <p class="text-center padding-top10"><strong>India Headoffice:</strong> 898 Udyog Vihar, Phase 1, Gurgaon, Haryana</p>
                </div>
            </div>
    </div>
    </div>
    
    
    
    
    <!-- Section tearm-->
	
		<div class="margin-top-90">
        <div class="section-title2 text-center">
            <h2 class="black-heading1">Eastbound Group</h2>
        </div>
        <div class="block-instagram owl-carousel" align="center" data-nav="false" data-dots="false" data-responsive='{"0":{"items":1},"600":{"items":4},"1000":{"items":10}}'>
            <a href="https://2hub.travel/"><img src="http://eastboundgroup.com/images/our_group/2hub.jpg" alt=""></a>
            <a href="http://www.chime.travel/"><img src="http://eastboundgroup.com/images/our_group/chimelogo.png" alt=""></a>
            <a href="http://eastboundgroup.com/"><img src="http://eastboundgroup.com/images/our_group/byond.jpg" alt=""></a>
            <a href="http://eastbounddiscoveries.com/"><img src="http://eastboundgroup.com/images/our_group/ebd.jpg" alt=""></a>
            <a href="http://btsindia.com/"><img src="http://eastboundgroup.com/images/our_group/bts1.png" alt=""></a>
		
        </div>
    </div>
    
    <div class="margin-top-90 old slider">
        <div class="section-title2 text-center">
            <h2 class="black-heading1">Eastbound Group Affiliations</h2>
        </div>
        <div class="block-instagram owl-carousel" data-nav="true" data-dots="false" data-responsive='{"0":{"items":1},"600":{"items":4},"1000":{"items":10}}'>
             <img src="images/contact-us/1.png" alt="">
             <img src="images/contact-us/2.png" alt="">
             <img src="images/contact-us/3.png" alt="">
             <img src="images/contact-us/4.png" alt="">
             <img src="images/contact-us/5.png" alt="">
             <img src="images/contact-us/6.png" alt="">
             <img src="images/contact-us/7.png" alt="">
             <img src="images/contact-us/8.png" alt="">
             <img src="images/contact-us/9.png" alt="">
			 <img src="images/contact-us/10.png" alt="">
             <img src="images/contact-us/aa.png" alt="">
             <img src="images/contact-us/bb.png" alt="">
             <img src="images/contact-us/cc.png" alt="">
             <img src="images/contact-us/dd.png" alt="">
        </div>
    </div>
	
    <!-- FOOTER -->
    <footer class="footer">
       <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-7">
                        <div class="footer-coppyright footer-social">
                            © Eastbound - Incomparable Luxury Travel Experiences
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://www.instagram.com/eastbound_official/" target="_blank"><i class="fa fa-instagram footer-social" aria-hidden="true"></i></a>
                        <a href="https://www.linkedin.com/company/east-bound-official/" target="_blank"><i class="fa fa-linkedin footer-social" aria-hidden="true"></i></a>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>